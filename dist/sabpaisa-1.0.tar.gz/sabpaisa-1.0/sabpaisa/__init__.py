from . import auth
from . import main
import subprocess
subprocess.call("pip install pycryptodomex")